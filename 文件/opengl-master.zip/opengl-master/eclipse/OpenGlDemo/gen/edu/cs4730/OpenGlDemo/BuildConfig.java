/** Automatically generated file. DO NOT MODIFY */
package edu.cs4730.OpenGlDemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}