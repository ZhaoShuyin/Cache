/** Automatically generated file. DO NOT MODIFY */
package com.droidnova.android.games.vortex;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}