/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.opengl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}